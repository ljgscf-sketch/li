import { env } from "cloudflare:workers";
import { getChatGPTUser } from "../../chatgpt-auth";
import { validateSyncData } from "../../../lib/validate-sync";
export const dynamic = "force-dynamic";
const headers = {"Cache-Control":"private, no-store", "X-Content-Type-Options":"nosniff"};
function json(data: unknown, status = 200) {return Response.json(data, {status, headers});}
function db(){
  if(!env.DB)throw new Error("Database binding unavailable");
  return env.DB;
}
async function read(userId: string) {
  const row = await db().prepare("SELECT revision, data FROM private_library_state WHERE user_id = ?").bind(userId).first<{revision:number;data:string}>();
  return {revision:row?.revision || 0,data:row?JSON.parse(row.data):{libraries:[]}};
}
export async function GET() {
  const user = await getChatGPTUser();
  if(!user) return json({error:"authentication_required"},401);
  return json({userId:user.userId,...await read(user.userId)});
}
export async function PUT(request: Request) {
  const user = await getChatGPTUser();
  if(!user) return json({error:"authentication_required"},401);
  const origin = request.headers.get("origin");
  if((origin && origin!==new URL(request.url).origin) || request.headers.get("sec-fetch-site")==="cross-site") return json({error:"forbidden_origin"},403);
  if(!request.headers.get("content-type")?.startsWith("application/json")) return json({error:"json_required"},415);
  const text=await request.text();
  if(new TextEncoder().encode(text).length>2000000)return json({error:"payload_too_large"},413);
  let body, data;
  try{
    body=JSON.parse(text);
    if(!Number.isSafeInteger(body.revision)||body.revision<0)throw new Error("revision");
    data=validateSyncData(body.data);
  }catch{return json({error:"invalid_library_data"},400);}
  const encoded=JSON.stringify(data), now=new Date().toISOString();
  let result;
  if(body.revision===0){
    result=await db().prepare("INSERT INTO private_library_state (user_id,revision,data,updated_at) VALUES (?,1,?,?) ON CONFLICT(user_id) DO NOTHING").bind(user.userId,encoded,now).run();
  }else{
    result=await db().prepare("UPDATE private_library_state SET revision=revision+1,data=?,updated_at=? WHERE user_id=? AND revision=?").bind(encoded,now,user.userId,body.revision).run();
  }
  if(!result.meta.changes)return json({error:"revision_conflict"},409);
  return json({revision:body.revision+1});
}
