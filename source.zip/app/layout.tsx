import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "小小识字家",
  description: "手机与 iPad 汉字闪卡，登录后私密同步字库。",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="zh-CN">
      <body className="antialiased">{children}</body>
    </html>
  );
}
