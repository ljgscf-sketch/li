const fsCore=require("node:fs"),vmCore=require("node:vm");
const coreContext={window:{}};vmCore.runInNewContext(fsCore.readFileSync(require("node:path").join(__dirname,"../public/sync-core.js"),"utf8"),coreContext);
const syncCore=coreContext.window.HanziSyncCore;
const fs=require('fs'),vm=require('vm'),assert=require('assert');
const html=require('../app/flashcard-html.ts').flashcardHTML;
const code=html.match(/<script>\s*([\s\S]*?)<\/script>/)[1].replace('})();', 'window.__test={pool,roundFor,randomNext,syncCloud,initCloud,validateLibraryBundle};})();');
function boot(store, server, userId="alice"){
 const nodes=new Map();
 function el(){return {value:'',textContent:'',innerHTML:'',style:{},dataset:{},disabled:false,children:[],listeners:{},classList:{add(){},remove(){},toggle(){}},setAttribute(){},replaceChildren(){this.children=[]},appendChild(x){this.children.push(x)},addEventListener(k,f){this.listeners[k]=f}}}
 for(const m of html.matchAll(/id="([^"]+)"/g)) nodes.set('#'+m[1],el());
 const groups={'.filter-btn':['all','fav'].map(filter=>Object.assign(el(),{dataset:{filter}})),'.segment button':['char','word'].map(mode=>Object.assign(el(),{dataset:{mode}})),'.chip':[2,3,4].map(len=>Object.assign(el(),{dataset:{len}}))};
 const document={querySelector(s){if(!nodes.has(s))nodes.set(s,el());return nodes.get(s)},querySelectorAll(s){return groups[s]||[]},createElement:el,addEventListener(){}};
 const ctx={document,window:{HanziSyncCore:syncCore},localStorage:{getItem:k=>store[k]??null,setItem:(k,v)=>store[k]=v,removeItem:k=>delete store[k]},setTimeout(){},clearTimeout(){},console,Blob,URL};
 if(server){
   ctx.location={protocol:'https:'};
   ctx.fetch=async(url,options={})=>{
     if(server.fail)throw new Error('offline');
     const state=server.accounts[userId]||{revision:0,data:{libraries:[]}};
     if(options.method==='PUT'){
       const request=JSON.parse(options.body);
       if(request.revision!==state.revision)return {status:409,ok:false,headers:{get:()=> 'application/json'},json:async()=>({})};
       server.accounts[userId]={revision:state.revision+1,data:JSON.parse(JSON.stringify(request.data))};
     }
     const result=server.accounts[userId]||state;
     return {status:200,ok:true,headers:{get:()=> 'application/json'},json:async()=>JSON.parse(JSON.stringify({userId,...result}))};
   };
 }
 vm.runInNewContext(code,ctx);
 return {api:ctx.window.__test,nodes,groups,click(id){nodes.get('#'+id).listeners.click({})},switch(id){nodes.get('#librarySelect').listeners.change({target:{value:id}})},type(id,value){nodes.get('#'+id).value=value},saved(){return JSON.parse(store['hanzi-libraries-v2'])}};
}

const tick=()=>new Promise(resolve=>setImmediate(resolve));
const server={accounts:{}};
(async()=>{
 const a=boot({},server);await tick();
 a.type('manualInput','山 shān');a.click('loadBtn');await a.api.syncCloud();
 assert.equal(server.accounts.alice.data.libraries[0].chars[0].char,'山');
 const b=boot({},server);await tick();
 assert.equal(b.nodes.get('#mainText').textContent,'山','new device loads private bank');
 // Concurrent disjoint edits from both devices are merged.
 a.type('manualInput','水 shuǐ');a.click('loadBtn');
 b.type('manualInput','天 tiān');b.click('loadBtn');
 await Promise.all([a.api.syncCloud(),b.api.syncCloud()]);await a.api.syncCloud();await b.api.syncCloud();
 assert.deepEqual(new Set(server.accounts.alice.data.libraries[0].chars.map(x=>x.char)),new Set(['山','水','天']));
 // Bob sees no Alice libraries.
 const bob=boot({},server,'bob');await tick();assert.equal(bob.api.pool().length,0);
 // Cloud failure preserves local edits and a subsequent reconnect uploads them.
 server.fail=true;a.type('manualInput','人 rén');a.click('loadBtn');await a.api.syncCloud();
 assert(a.api.pool().some(x=>x.char==='人'));
 server.fail=false;await a.api.syncCloud();assert(server.accounts.alice.data.libraries[0].chars.some(x=>x.char==='人'));
 // Namespaced state resumes pending work after a reload.
 const local={};const c=boot(local,server);await tick();server.fail=true;c.type('manualInput','大 dà');c.click('loadBtn');
 server.fail=false;const c2=boot(local,server);await tick();await c2.api.syncCloud();
 assert(server.accounts.alice.data.libraries[0].chars.some(x=>x.char==='大'));
 console.log('PASS: automatic cloud bootstrap, two-device sync, concurrent edits, separate accounts, offline/reconnect and reload of pending edits');
})().catch(e=>{console.error(e);process.exitCode=1});
