const fsCore=require("node:fs"),vmCore=require("node:vm");
const coreContext={window:{}};vmCore.runInNewContext(fsCore.readFileSync(require("node:path").join(__dirname,"../public/sync-core.js"),"utf8"),coreContext);
const syncCore=coreContext.window.HanziSyncCore;
const fs=require('fs'),vm=require('vm'),assert=require('assert');
const html=require('../app/flashcard-html.ts').flashcardHTML;
const code=html.match(/<script>\s*([\s\S]*?)<\/script>/)[1].replace('})();', 'window.__test={pool,roundFor,randomNext,syncCloud,initCloud,validateLibraryBundle};})();');
function boot(store, remote){
 const nodes=new Map();
 function el(){return {value:'',textContent:'',innerHTML:'',style:{},dataset:{},disabled:false,children:[],listeners:{},classList:{add(){},remove(){},toggle(){}},setAttribute(){},replaceChildren(){this.children=[]},appendChild(x){this.children.push(x)},addEventListener(k,f){this.listeners[k]=f}}}
 for(const m of html.matchAll(/id="([^"]+)"/g)) nodes.set('#'+m[1],el());
 const groups={'.filter-btn':['all','fav'].map(filter=>Object.assign(el(),{dataset:{filter}})),'.segment button':['char','word'].map(mode=>Object.assign(el(),{dataset:{mode}})),'.chip':[2,3,4].map(len=>Object.assign(el(),{dataset:{len}}))};
 const document={querySelector(s){if(!nodes.has(s))nodes.set(s,el());return nodes.get(s)},querySelectorAll(s){return groups[s]||[]},createElement:el,addEventListener(){}};
 const ctx={document,window:{},localStorage:{getItem:k=>store[k]??null,setItem:(k,v)=>store[k]=v,removeItem:k=>delete store[k]},setTimeout(){},clearTimeout(){},console,Blob,URL};
 if(remote){
   ctx.location={protocol:'https:'};
   ctx.fetch=async()=>({ok:true,json:async()=>remote.value});
 }
 vm.runInNewContext(code,ctx);
 return {api:ctx.window.__test,nodes,groups,click(id){nodes.get('#'+id).listeners.click({})},switch(id){nodes.get('#librarySelect').listeners.change({target:{value:id}})},type(id,value){nodes.get('#'+id).value=value},saved(){return JSON.parse(store['hanzi-libraries-v2'])}};
}
const store={'hanzi-flashcards-v1':JSON.stringify([{char:'山',pinyin:'shān',example:'大山'}]),'hanzi-favorites-v1':'["c:山"]'};
let app=boot(store);
assert.equal(app.nodes.get('#mainText').textContent,'山');
assert.equal(app.saved().libraries[0].favorites[0],'c:山');
app.type('libraryName','第二课'); app.click('newLibraryBtn');
const id=app.saved().activeLibraryId;
assert.equal(app.saved().libraries.length,2);
assert.equal(app.nodes.get('#againBtn').disabled,true);
app.type('manualInput','水 shuǐ');app.click('loadBtn');app.click('randomBtn');app.click('favoriteBtn');
assert.equal(app.saved().libraries.find(x=>x.id===id).chars[0].char,'水');
app.switch('default');assert.equal(app.nodes.get('#mainText').textContent,'山');assert.equal(app.nodes.get('#againBtn').disabled,true);
assert.deepEqual(app.saved().libraries.find(x=>x.id==='default').favorites,['c:山']);
app.switch(id);app.type('libraryName','水的字库');app.click('renameLibraryBtn');
app=boot(store);assert.equal(app.saved().activeLibraryId,id);assert.equal(app.nodes.get('#mainText').textContent,'水');
assert.equal(app.saved().libraries.find(x=>x.id===id).name,'水的字库');
app.click('clearLibraryBtn');app.click('cancelClearBtn');assert.equal(app.saved().libraries.find(x=>x.id===id).chars.length,1);
app.click('clearLibraryBtn');app.click('confirmClearBtn');assert.equal(app.saved().libraries.find(x=>x.id===id).chars.length,0);assert.equal(app.saved().libraries[0].chars.length,1);
app.click('deleteLibraryBtn');app.click('confirmClearBtn');assert.equal(app.saved().libraries.length,1);assert.equal(app.saved().activeLibraryId,'default');
assert.equal(app.nodes.get('#deleteLibraryBtn').disabled,true);
console.log('PASS: legacy migration, create, import, favorites isolation, switch/history reset, rename, reload, clear/cancel, delete, last-library guard');
// Exercise the actual closure through an in-memory-only test export.

const roundStore={'hanzi-flashcards-v1':JSON.stringify(['山','水','天','空','白','云','大','小','人'].map(char=>({char,pinyin:'test'})))};
let r=boot(roundStore);
function text(){return r.nodes.get('#mainText').textContent}
const n=r.api.pool().length;
let previousLast='';
for(let round=0;round<25;round++){
 const draws=[];
 if(round===0) draws.push(text());
 while(draws.length<n){r.click('randomBtn');draws.push(text())}
 assert.equal(new Set(draws).size,n,'every character appears once');
 if(previousLast)assert.notEqual(draws[0],previousLast,'round boundary avoids repeat');
 previousLast=draws.at(-1);
 assert.match(r.nodes.get('#progressText').textContent,new RegExp(`${n} / ${n}$`));
 assert.equal(r.nodes.get('#progressFill').style.width,'100%');
}
// Reload resumes the stored round rather than forgetting used cards.
r=boot(roundStore);let first=text();r.click('randomBtn');let second=text();assert.notEqual(first,second);
let used=r.api.roundFor(r.api.pool()).state.drawn.slice();
r=boot(roundStore);assert(!used.includes(text()),'reload resumes remaining cards');
const before=r.api.roundFor(r.api.pool()).state.drawn.length;
r.click('randomBtn');r.click('againBtn');assert.equal(r.api.roundFor(r.api.pool()).state.drawn.length,before+1,'review does not consume queue');
// Word coverage is exhaustive within the eligible real-word bank.
r.groups['.segment button'][1].listeners.click();
const words=r.api.pool().map(x=>x.word);
assert(words.includes('白云'));assert(words.includes('大山'));assert(words.includes('山水'));assert(words.includes('山人')===false);
assert.equal(words.length,new Set(words).size);
const allowed=new Set(['山','水','天','空','白','云','大','小','人']);
assert(words.every(w=>[...w].every(c=>allowed.has(c))));
const wordDraws=[text()];while(wordDraws.length<words.length){r.click('randomBtn');wordDraws.push(text())}
assert.equal(new Set(wordDraws).size,words.length);
assert.deepEqual([...wordDraws].sort(),[...words].sort());
console.log(`PASS: 25 complete character rounds, boundaries, saved progress, review, and all ${words.length} eligible real words`);
// Even a character without offline pinyin participates in the full round.
const missing=boot({'hanzi-flashcards-v1':JSON.stringify([{char:'龘',pinyin:''}])});
assert.equal(missing.api.pool().length,1);assert.equal(missing.nodes.get('#mainText').textContent,'龘');
console.log('PASS: no character skipped because of missing pinyin');

