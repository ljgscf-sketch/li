const fsCore=require("node:fs"),vmCore=require("node:vm");
const coreContext={window:{}};vmCore.runInNewContext(fsCore.readFileSync(require("node:path").join(__dirname,"../public/sync-core.js"),"utf8"),coreContext);
const syncCore=coreContext.window.HanziSyncCore;
const fs=require('node:fs'),assert=require('node:assert/strict'),vm=require('node:module');
const {DatabaseSync}=require('node:sqlite');
const {validateSyncData}=require('../lib/validate-sync.ts');
const db=new DatabaseSync(':memory:');
db.exec('CREATE TABLE private_library_state(user_id TEXT PRIMARY KEY, revision INTEGER NOT NULL, data TEXT NOT NULL, updated_at TEXT NOT NULL)');
const env={DB:{prepare(sql){return {bind(...args){return {async first(){return db.prepare(sql).get(...args)||null},async run(){const r=db.prepare(sql).run(...args);return {meta:{changes:Number(r.changes)}}}}}}}}};
let identity={userId:'alice'};
const source=vm.stripTypeScriptTypes(fs.readFileSync(require('node:path').join(__dirname,'../app/api/sync/route.ts'),'utf8').replace(/^import .*;$/mg,''),{mode:'strip'}).replace(/export /g,'');
const api=new Function('env','getChatGPTUser','validateSyncData',source+';return {GET,PUT};')(env,async()=>identity,validateSyncData);
const data={libraries:[{id:'a',name:'第一课',chars:[{char:'山',pinyin:'shān',example:'大山'}]}]};
const put=(revision,override={})=>api.PUT(new Request('https://example.com/api/sync',{method:'PUT',headers:{'content-type':'application/json',origin:'https://example.com'},body:JSON.stringify({revision,data,...override})}));
(async()=>{
 identity=null;assert.equal((await api.GET()).status,401);assert.equal((await put(0)).status,401);
 identity={userId:'alice'};assert.equal((await api.GET()).status,200);assert.equal((await put(0)).status,200);
 const concurrent=await Promise.all([put(1),put(1)]);assert.deepEqual(concurrent.map(x=>x.status).sort(),[200,409]);
 identity={userId:'bob'};assert.equal((await (await api.GET()).json()).data.libraries.length,0,'account isolation');
 assert.equal((await put(0,{userId:'alice'})).status,200); // payload cannot choose account
 identity={userId:'alice'};assert.equal((await (await api.GET()).json()).revision,2,'Bob did not modify Alice');
 assert.equal((await api.PUT(new Request('https://example.com/api/sync',{method:'PUT',headers:{'content-type':'application/json',origin:'https://evil.example'},body:'{}'}))).status,403);
 assert.equal((await put(2,{data:{libraries:[{id:'bad'}]}})).status,400);
 assert.equal((await put(-1)).status,400);
 console.log('PASS: authentication, account isolation, forged account rejection, atomic stale-write conflicts, CSRF and invalid payload rejection');
})().catch(e=>{console.error(e);process.exitCode=1});
