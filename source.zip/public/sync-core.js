/* Shared by the browser and Node tests. Contains no credentials or user data. */
(function(root){
  function same(a,b){return JSON.stringify(a)===JSON.stringify(b)}
  function copy(x){return x===undefined ? undefined : JSON.parse(JSON.stringify(x))}
  function mergeBanks(base,local,remote){
    const bm=new Map(base.libraries.map(x=>[x.id,x]));
    const lm=new Map(local.libraries.map(x=>[x.id,x]));
    const rm=new Map(remote.libraries.map(x=>[x.id,x]));
    const ids=new Set([...rm.keys(),...lm.keys(),...bm.keys()]);
    const libraries=[],conflicts=[];
    for(const id of ids){
      const b=bm.get(id),l=lm.get(id),r=rm.get(id);
      if(same(l,b)){if(r)libraries.push(copy(r));continue;}
      if(same(r,b)||same(l,r)){if(l)libraries.push(copy(l));continue;}
      // An edit wins over a concurrent deletion; never silently discard edited data.
      if(!l||!r){const kept=l||r;if(kept){libraries.push(copy(kept));conflicts.push(id);}continue;}
      const merged={id,name:same(l.name,b?.name)?r.name:l.name,chars:[]};
      let conflictingName=!same(l.name,r.name)&&!same(l.name,b?.name)&&!same(r.name,b?.name);
      const bc=new Map((b?.chars||[]).map(x=>[x.char,x]));
      const lc=new Map(l.chars.map(x=>[x.char,x]));
      const rc=new Map(r.chars.map(x=>[x.char,x]));
      let conflictingChar=false;
      for(const ch of new Set([...rc.keys(),...lc.keys(),...bc.keys()])){
        const before=bc.get(ch),left=lc.get(ch),right=rc.get(ch);
        let chosen;
        if(same(left,before))chosen=right;
        else if(same(right,before)||same(left,right))chosen=left;
        else{chosen=left||right;conflictingChar=true;}
        if(chosen)merged.chars.push(copy(chosen));
      }
      libraries.push(merged);
      if(conflictingChar||conflictingName){
        // Keep the other version as a visible library, including conflicting readings.
        const duplicate=copy(r);let copyId=`${id}:conflict`,suffix=2;
        while(ids.has(copyId)||libraries.some(x=>x.id===copyId))copyId=`${id}:conflict-${suffix++}`;
        duplicate.id=copyId;duplicate.name=`${r.name.slice(0,30)}（另一设备版本）`;
        libraries.push(duplicate);conflicts.push(id);
      }
    }
    return {libraries,conflicts};
  }
  const api={same,mergeBanks};
  if(typeof module!=="undefined"&&module.exports)module.exports=api;
  else root.HanziSyncCore=api;
})(typeof window!=="undefined"?window:globalThis);
