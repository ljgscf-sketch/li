export function validateSyncData(value: unknown) {
  const input=value as {libraries:unknown[]};
  if(!input||!Array.isArray(input.libraries)||input.libraries.length>200)throw new Error("libraries");
  const ids=new Set<string>();let total=0;
  return {libraries:input.libraries.map(raw=>{
    const item=raw as {id:string;name:string;chars:unknown[]};
    if(!item||typeof item.id!=="string"||!item.id||item.id.length>200||ids.has(item.id)||typeof item.name!=="string"||!item.name.trim()||item.name.length>60||!Array.isArray(item.chars))throw new Error("library");
    ids.add(item.id);
    total+=item.chars.length;if(total>20000)throw new Error("entries");
    const seen=new Set<string>();
    return {id:item.id,name:item.name.trim(),chars:item.chars.map(rawChar=>{
      const entry=rawChar as {char:string;pinyin?:string;example?:string};
      if(!entry||typeof entry.char!=="string"||!/^[\u3400-\u9fff]$/.test(entry.char)||seen.has(entry.char))throw new Error("character");
      seen.add(entry.char);
      if(typeof entry.pinyin!=="string"||entry.pinyin.length>100||typeof entry.example!=="string"||entry.example.length>200)throw new Error("entry");
      return {char:entry.char,pinyin:entry.pinyin,example:entry.example};
    })};
  })};
}
