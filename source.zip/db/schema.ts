import { sqliteTable, text, integer } from "drizzle-orm/sqlite-core";
export const privateLibraryState = sqliteTable("private_library_state", {
  userId: text("user_id").primaryKey(),
  revision: integer("revision").notNull().default(0),
  data: text("data").notNull(),
  updatedAt: text("updated_at").notNull(),
});
